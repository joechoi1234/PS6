
totalbonus = 0.0
f = open("PS3.txt", "r")

bonus = 0
Lastname = " "
Salary = 0

count = 0


for line in f:
  
  if count % 2 == 0:
    Salary = int(line)
    if Salary >= 100000:
      bonus = Salary * .2
    elif Salary >= 50000:
      bonus = Salary * .15
    else:
      bonus = Salary * .1
  else:
    Lastname = line.strip()
    print("Last name is: " , Lastname)
    print("Salary is: " , Salary)
    print("Bonus is: " , bonus)
    print()
  
    
    totalbonus = totalbonus + bonus 
  
  count = count + 1

print("Total bonus: " , totalbonus)


    




  
    
  
  
  