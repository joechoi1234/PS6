
f = open("PS6.txt", "r")
count = 0.0
totaltuition = 0.0

name = str(f.readline())

while name != "":
  dcode = str(f.readline())
  creditqty = float(f.readline())
  if dcode == '0':
    creditcost = 250
  else:
    creditcost = 500
  tuition = (creditqty * creditcost)
  totaltuition = (totaltuition + tuition )
  count = count + 1
  print("Last name: " , name)
  print("Credits taken: " , creditqty)
  print("Tuition owed: " , tuition)

  name = str(f.readline())

print("Sum tuition: " , totaltuition)
print("Number of students: " , count)