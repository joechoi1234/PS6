

response = input("Do you want to compute ending balance(Yes or No): ")

while response == "Yes":
  
  p = float(input("Enter Principle: "))
  r = float(input("Enter interest rate: "))
  for count in range(1, 6, ):
    i = p * r 
    eb = p + i
    print (count," ",p," ", eb)
    p = eb
  response = input("Do you want to compute ending balance(Yes or No): ")
  
  