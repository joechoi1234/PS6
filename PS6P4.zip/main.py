
f = open("p4.txt", "r")

c = 0.0
totp_ex = 0.0

item = str(f.readline().rstrip('\n'))

while item != "":
  qnty = float(f.readline())
  price = float(f.readline())

  ep = qnty * price
  totp_ex = totp_ex + ep
  c = c + 1

  print("Item is:           " , item)
  print("Quantity is:       " , qnty)
  print("Price is:          " , price)
  print("Extended Price is: " , ep)

  item = str(f.readline().rstrip('\n'))

print("Total Extended Price:   " , totp_ex)
print("Total Number of Orders: " , c)
avg = totp_ex / c
print("Average Order:          " , avg)
